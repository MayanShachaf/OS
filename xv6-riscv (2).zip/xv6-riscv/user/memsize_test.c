#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char** argv)
{
    fprintf(2,"Memory size: %d\n",memsize());
    char* arr = malloc(20000);
    fprintf(2,"Memory size: %d\n",memsize());
    free(arr);
    fprintf(2,"Memory size: %d\n",memsize());
    return 0;
}