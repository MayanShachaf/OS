#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define LOW 10
#define NORMAL 5
#define HIGH 1

void work();

int main(int argc, char *argv[])
{
    int i;
    for(i = 0; i < 5; i++ )
    {
        int pid = fork();
        if (pid == 0)
        {
            set_ps_priority(LOW);
            work();
            exit(0, "");
        }
    }
    for(i = 0; i < 5; i++ )
    {
        int pid = fork();
        if (pid == 0)
        {
            set_ps_priority(HIGH);
            work();
            exit(0, "");
        }
    }

    for(i = 0; i < 10; i++ )
        wait(0, "");

    exit(0, "");
}

void work()
{
    int i, j;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 100000; j++)
        {
            printf("");
        }

        // sleep for 1 second every 100,000 iterations
        sleep(1);
    }

}
