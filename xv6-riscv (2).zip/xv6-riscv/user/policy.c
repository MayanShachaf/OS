#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char **argv)
{
    int policy;

    // Check if argument is provided
    if (argc < 2)
    {
        printf("Error: missing policy argument\n");
        return -1;
    }

    // Parse the policy argument
    policy = atoi(argv[1]);

    if (policy < 0 || policy > 2)
    {
        printf("Error: invalid policy\n");
        return -1;
    }
    // Call the set_policy() system call
    if (set_policy(policy) < 0)
    {
        printf("Error: invalid policy\n");
        return -1;
    }
    return 0;
}