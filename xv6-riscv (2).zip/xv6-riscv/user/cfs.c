#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define LOW 2
#define NORMAL 1
#define HIGH 0

void work();

int main(int argc, char *argv[])
{
    int pid_low = fork();
    if (pid_low == 0)
    {
        set_cfs_priority(LOW);
        sleep(1);
        work();
        exit(0, "");
    }

    int pid_normal = fork();
    if (pid_normal == 0)
    {
       
        set_cfs_priority(NORMAL);
        sleep(5);
        work();
        exit(0, "");
    }

    int pid_high = fork();
    if (pid_high == 0)
    {
        set_cfs_priority(HIGH);
        sleep(9);
        work();
        exit(0, "");
    }



    wait(0, "");
    wait(0, "");
    wait(0, "");


    exit(0, "");
}

void work()
{
    int i, j;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 100000; j++)
        {
            printf("");
        }

        // sleep for 1 second every 100,000 iterations
        sleep(1);
    }

    // print process statistics
    int stats[4];
    get_cfs_stats(getpid(), stats);
    printf("Proc Stats: PID: %d, CFS priority: %d, run time: %d, sleep time: %d, runnable time: %d\n\n", getpid(), stats[0], stats[1], stats[2], stats[3]);
}
